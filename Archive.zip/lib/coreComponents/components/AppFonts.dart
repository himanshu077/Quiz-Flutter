
import 'dart:io';

bool _isIos = Platform.isIOS;
class AppFonts{
  // static final double s7 = _isIos ? 9 : 7;
  // static final double s8 = _isIos ? 8 : 6;
  // static final double s10 = _isIos ? 12 : 10;
  // static final double s11 = _isIos ? 13 : 11;
  // static final double s12 = _isIos ? 14 : 12;
  // static final double s13 = _isIos ? 15 : 13;
  // static final double s14 = _isIos ? 16 : 14;
  // static final double s15 = _isIos ? 17 : 15;
  // static final double s16 = _isIos ? 18 : 16;
  // static final double s17 = _isIos ? 19 : 17;
  // static final double s18 = _isIos ? 20 : 18;
  // static final double s20 = _isIos ? 22 : 20;
  // static final double s22 = _isIos ? 24 : 22;
  // static final double s24 = _isIos ? 26 : 24;
  // static final double s28 = _isIos ? 30 : 28;
  // static final double s30 = _isIos ? 32 : 30;
  // static final double s34 = _isIos ? 36 : 34;
  // static final double s40 = _isIos ? 42 : 40;



  static final double s7 = _isIos ? 7 : 7;
  static final double s8 = _isIos ? 8 : 8;
  static final double s10 = _isIos ? 10 : 10;
  static final double s11 = _isIos ? 11 : 11;
  static final double s12 = _isIos ? 12 : 12;
  static final double s13 = _isIos ? 13 : 13;
  static final double s14 = _isIos ? 14 : 14;
  static final double s15 = _isIos ? 15 : 15;
  static final double s16 = _isIos ? 16 : 16;
  static final double s17 = _isIos ? 17 : 17;
  static final double s18 = _isIos ? 18 : 18;
  static final double s20 = _isIos ? 20 : 20;
  static final double s22 = _isIos ? 22 : 22;
  static final double s24 = _isIos ? 24 : 24;
  static final double s28 = _isIos ? 28 : 28;
  static final double s30 = _isIos ? 30 : 30;
  static final double s34 = _isIos ? 34 : 34;
  static final double s40 = _isIos ? 40 : 40;
}