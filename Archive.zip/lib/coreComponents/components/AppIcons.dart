
const String _iconPath = 'assets/icons/';

class AppIcons{
  static const String background = '${_iconPath}bg.svg';
  static const String clock = '${_iconPath}clock.svg';
  static const String backButton = '${_iconPath}back.png';

}